require 'sinatra'
require 'rest_client'
require 'data_mapper'
require 'json'
require 'sinatra/flash'
require 'will_paginate'
require 'will_paginate/array'
require 'date'
require 'time'
require 'rubygems'

enable :sessions
#set :session_secret, 'This is a secret key' # security waring 안뜨게 하는것.

DataMapper::setup(:default, "sqlite3://#{File.dirname(__FILE__)}/server.db")

class User
  include DataMapper::Resource
  property :id, Serial
  property :user_email, String 
  property :nickname, String
  property :user_password, String
  property :score, Integer
  property :user_ip, String 
  property :user_login, DateTime 
  property :ranking, String 
  property :admin, Boolean
  property :created_at, DateTime 

  validates_uniqueness_of :user_email
  validates_uniqueness_of :nickname
end

class Admin_Board
  include DataMapper::Resource
  property :id, Serial
  property :board_user, String
  property :title, String 
  property :description, String, :length => 1000000000
  property :c_size, DateTime
  property :b_date, DateTime
end

class Board
  include DataMapper::Resource
  property :id, Serial
  property :board_user, String
  property :title, String 
  property :description, String, :length => 1000000000
  property :board_hits, Integer
  property :comment_hits, Integer
  property :b_date, DateTime
end

class Comment
  include DataMapper::Resource
  property :id, Serial
  property :content, Text
  property :user_id, Integer
  property :board_id, Integer
  property :c_date, DateTime
end

class Quiz
  include DataMapper::Resource
  property :id, Serial
  property :title, String 
  property :description, String, :length => 1000000000
  property :made_by, String
  property :category, String
  property :solvers, Integer
  property :answer, String
  property :score, Integer
  property :b_date, DateTime
end

class Solvers
  include DataMapper::Resource
  property :id, Serial
  property :quiz_board_id, String
  property :quiz_id, String
end


DataMapper.finalize

User.auto_upgrade!
Admin_Board.auto_upgrade!
Board.auto_upgrade!
Comment.auto_upgrade!
Quiz.auto_upgrade!
Solvers.auto_upgrade!

not_found do
  erb:'404'
end
helpers do
  'Boom'
end

error 500 do | exception |
    "서버에 오류가 발생했습니다. #{ exception }"
end

get '/asdasd' do
  a = Quiz.all
  a.destroy
  redirect '/admin/'
end

#삭제
get '/admin/challenges/:id' do
  solvers = Solvers.first(:id => params[:id])
  a = Quiz.first(:id => solvers.quiz_board_id )
  a.solvers = a.solvers - 1
  a.save
  solvers.destroy
  redirect '/admin/challenges'
end
#삭제

#문제 드랍다운
get '/' do 
	erb:index
end

get '/main/' do 
  @board = Quiz.all.reverse
  erb:challenges
end

get '/register' do
	erb:join
end

get '/user_delete/:user_id' do
  user = User.first(:id => params[:user_id])
  user.destroy
  redirect '/admin/'
end

#문제

get '/main/challenges' do 
  @board = Quiz.all.reverse
  erb:challenges
end

get '/admin/challenges' do
  @board = Quiz.all.reverse
  erb:admin_challenges
end
get '/admin/challenges/write' do
 erb:admin_challenges_write
end

get '/admin/make_admin/:user_id' do
  user = User.first(:id => params[:user_id])
  if user.admin == false
    user.admin = true
  else 
    user.admin = false
  end
  user.save
  redirect '/admin/'
end

end

post '/admin/challenges/add_board' do 

  b = Quiz.new
  b.title = params[:title]
  b.score = params[:score]
  b.category = params[:category]
  b.answer = params[:answer]
  b.made_by = User.first(:user_email => session[:email]).nickname
  b.description = params[:description]
  b.b_date = Time.now
  b.solvers = 0
  b.save

  redirect "/admin/challenges"
end

get '/admin/challenges/board_edit/:board_id' do
  @board = Quiz.first(:id => params[:board_id])
  erb:admin_challenges_edit
end

post '/admin/challenges/board_edit' do

  board = Quiz.first(:id => params[:board_id])
board.title = params[:title]
board.score = params[:score]
board.category = params[:category]
board.answer = params[:answer]
board.made_by = User.first(:user_email => session[:email]).nickname
board.description = params[:description]
board.save
redirect "/admin/challenges/board/#{params[:board_id]}"
end

get '/admin/challenges/board/:id' do 

  @board = Quiz.first(:id => params[:id])
    @u = Solvers.all(:quiz_board_id => params[:id])
    erb :admin_challenges_detail
end

get '/admin/challenges/board_delete/:board_id' do
  board = Quiz.first(:id => params[:board_id])
  board.destroy
  redirect '/admin/challenges'
end

get '/main/challenges/:id' do 
  @board = Quiz.first(:id => params[:id])
 if @board.made_by.nil?
  redirect "/main/board/"
else
  erb :q_detail
end
end

post '/main/challenges/answer' do
  u = User.first(:user_email  => session[:email])
  a = Quiz.first(:id => params[:board_id] )
  s = Solvers.first(:quiz_board_id => a.id , :quiz_id => session[:email])
  if a.answer == params[:answer]
    if s.nil?
      u.score = u.score + a.score
      u.save
      a.solvers = a.solvers + 1
      a.save
    s = Solvers.new
    s.quiz_board_id = a.id
    s.quiz_id = session[:email]
    s.save
    flash[:notice] = "축하드립니다."
    redirect '/main/challenges'

  else
    flash[:notice] = "이미 푸셨습니다."
    redirect '/main/challenges'
  end

else
  flash[:notice] = "정답이 틀렸습니다."
  redirect '/main/challenges'
end
end


#문제





get '/main/ranking' do 
  @u = User.all.sort! {|x, y| x.score <=> y.score}.reverse.paginate(:per_page => 100)
  erb:ranking
end

get '/main/myuser' do 
	erb:myuser
end

get '/admin/' do
  @users = User.all
  erb:admin
end

get '/admin/board' do
  @board = Admin_Board.all
  erb:adminboard
end

get '/admin/board' do
  @board = Board.all.reverse.paginate(:page => params[:page], :per_page => 10)
  @adminboard = Admin_Board.all
  erb:board
end

get '/admin/board' do
  @board = Admin_Board.all
  erb:adminboard
end

get '/admin/write' do
 erb:adminwrite
end

post '/admin/add_board' do 

  b = Admin_Board.new
  b.title = params[:title]
  b.board_user = User.first(:user_email => session[:email]).nickname
  b.description = params[:description]
  b.b_date = Time.now
  b.save

  redirect "/admin/board"
end

get '/admin/board_edit/:board_id' do
  @board = Admin_Board.first(:id => params[:board_id])
  erb:adminboard_edit
end

post '/admin/board_edit' do

  board = Admin_Board.first(:id => params[:board_id])
board.title = params[:title]
board.description = params[:description]
board.save
redirect "/admin/board/#{params[:board_id]}"
end

get '/admin/board/:id' do 

  @board = Admin_Board.first(:id => params[:id])
  @comments = Comment.all(:board_id => params[:id])
  if @board.board_user.nil?
    redirect "/admin/board/"
  else
    erb :admindetail
  end
end

get '/main/adminboard/:id' do 
  @board = Admin_Board.first(:id => params[:id])
  @comments = Comment.all(:board_id => params[:id])
  if @board.board_user.nil?
    redirect "/main/board/"
  else
    erb :d_detail
  end
end




get '/main/write' do
  erb:write
end

get '/main/board' do
  @board = Board.all.reverse.paginate(:page => params[:page], :per_page => 10)
  @adminboard = Admin_Board.all
  erb:board1
end

get '/main/board/:id' do 

  @board = Board.first(:id => params[:id])
  @comments = Comment.all(:board_id => params[:id])
  if @board.board_user.nil?
    redirect "/main/board/"    
  else
    erb :detail
  end
end

get '/main/board/write' do

 erb:write

end

get '/main/board_edit/:board_id' do
  @board = Board.first(:id => params[:board_id])
  a = User.first(:user_email => session[:email]).nickname
  user = User.first(:user_email => session[:email])
  if a ==  @board.board_user  or user.admin == true
    erb:board_edit
  else
    flash[:notice] = "글쓴이만 글수정이가능합니다."
    redirect '/main/board'
  end
end

get '/main/comment_delete/:comment_id' do
  comment = Comment.first(:id => params[:comment_id])
  a = User.first(:user_email => session[:email]).id
  if a == comment.user_id
    comment.destroy
    redirect back
  else
    redirect back
  end
end

post '/main/write' do 

  bb = Board.first(:id => params[:board_id])
  if !bb.comment_hits.nil?
    bb.comment_hits = bb.comment_hits + 1
    bb.save
  else
    bb.comment_hits = 0
    bb.save
  end
  p = Comment.new
  p.content = params[:content]
  p.user_id = User.first(:user_email => session[:email]).id
  p.board_id = params[:board_id]
  p.c_date = Time.now
  p.save

  redirect "/main/board/#{params[:board_id]}"
end

post '/main/add_board' do 


  b = Board.new
  b.comment_hits = 0
  b.title = params[:title]
  b.board_user = User.first(:user_email => session[:email]).nickname
  b.description = params[:description]
  b.b_date = Time.now
  b.save

  flash[:notice] = "글이 업로드 되었습니다."
  redirect "/main/board"
end

post '/main/board_edit' do

  board = Board.first(:id => params[:board_id])
  a = User.first(:user_email => session[:email]).nickname
  user = User.first(:user_email => session[:email])
  if a == board.board_user  or user.admin == true
#post = Board.all(:id => params[:board_id])
board.title = params[:title]
board.description = params[:description]
board.save
flash[:notice] = "글수정이 완료되었습니다."
redirect "/main/board/#{params[:board_id]}"

else
  flash[:notice] = "글쓴이만 글수정이가능합니다."
  redirect "/main/board/"
end
end

get '/admin/board_delete/:board_id' do
  board = Admin_Board.first(:id => params[:board_id])
  board.destroy
  redirect '/admin/board'
end


get '/main/board_delete/:board_id' do
  board = Board.first(:id => params[:board_id])
  a = User.first(:user_email => session[:email]).nickname
  user = User.first(:user_email => session[:email])
  if a == board.board_user or user.admin == true
    board.destroy
    flash[:notice] = "글삭제가 완료되었습니다."
    redirect '/main/board'
  else
    flash[:notice] = "글쓴이만 삭제 가능합니다."
    redirect '/main/board'
  end
end



get '/logout' do
  session.clear
  redirect '/'
end

post '/join_process' do
  a = User.first(:nickname => params[:nickname])
  b = User.first(:user_email => params[:user_emailail])
  if a.nil?
    if b.nil?
  n_user = User.new
  n_user.user_email = params[:user_email]
  n_user.nickname = params[:nickname]

  n_user.user_ip = request.env['REMOTE_ADDR'].split(',').first

  md5_password = Digest::MD5.hexdigest(params[:user_password])
  n_user.user_password = md5_password
  n_user.score = 0
  n_user.admin = false
  n_user.created_at = Time.now
  n_user.save
  flash[:notice] = "가입 완료."
  redirect '/'
else
  flash[:notice] = "이메일 주소가 이미사용중입니다."
  redirect '/'
end
else
  flash[:notice] = "닉네임이 이미 사용중입니다."
  redirect '/'
end
end


post '/login_process' do

  database_user = User.first(:user_email => params[:user_email])

  md5_user_password = Digest::MD5.hexdigest(params[:user_password])

  if !database_user.nil?
    if database_user.user_password == md5_user_password
        session[:email] = params[:user_email]
        database_user.user_login = Time.now
        database_user.save
        redirect '/main/'
      else
        flash[:notice] = "비밀번호 틀림"
        redirect '/'
      end
    else
      flash[:notice] = "아이디가 틀림"
      redirect '/'
    end

  end

  ['/admin/*'].each do |path|
    before path do
      user = User.first(:user_email => session[:email])
      if (user.admin == false)
        redirect '/'
      end
    end
  end

  ['/main/*'].each do |path|
    before path do
      user = User.first(:user_email => session[:email])
      if (user.nil?)
        redirect '/'
      end
    end
  end